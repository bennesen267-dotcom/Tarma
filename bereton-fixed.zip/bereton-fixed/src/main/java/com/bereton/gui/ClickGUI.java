package com.bereton.gui;

import com.bereton.BeretonClient;
import com.bereton.module.Category;
import com.bereton.module.Module;
import com.bereton.module.settings.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * ClickGUI — dark panel per category, module buttons, right-click opens settings.
 *
 * Layout:
 *  - One panel per Category, arranged horizontally.
 *  - Each panel: header bar + module rows.
 *  - Left-click module row → toggle.
 *  - Right-click module row → open inline settings panel below the module.
 */
public class ClickGUI extends Screen {

    // Panel geometry
    private static final int PANEL_WIDTH   = 110;
    private static final int PANEL_GAP     = 6;
    private static final int HEADER_HEIGHT = 14;
    private static final int MODULE_HEIGHT = 12;
    private static final int START_X       = 8;
    private static final int START_Y       = 8;

    // Colors
    private static final int COL_PANEL_BG  = 0xCC1A1A2E;
    private static final int COL_HEADER    = 0xFF16213E;
    private static final int COL_MOD_BG    = 0xAA0F3460;
    private static final int COL_MOD_ON    = 0xFF533483;
    private static final int COL_TEXT      = 0xFFE0E0E0;
    private static final int COL_TEXT_DIM  = 0xFF888888;
    private static final int COL_SETTINGS  = 0xCC11112A;
    private static final int COL_ACCENT    = 0xFF8B5CF6;

    // Which module has its settings panel open
    private Module openSettings = null;
    // Drag state for panels
    private final Map<Category, int[]> panelPos = new HashMap<>();

    private int dragCat  = -1;
    private int dragOffX = 0;
    private int dragOffY = 0;

    public ClickGUI() {
        super(Text.literal("Bereton"));
        for (Category cat : Category.values()) {
            int idx = cat.ordinal();
            panelPos.put(cat, new int[]{ START_X + idx * (PANEL_WIDTH + PANEL_GAP), START_Y });
        }
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        // Right Shift (344) menüyü kapatır; ESC zaten Screen tarafından kapatılır
        if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_SHIFT) {
            this.close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // Dim background slightly
        ctx.fill(0, 0, this.width, this.height, 0x55000000);

        for (Category cat : Category.values()) {
            int[] pos = panelPos.get(cat);
            int px = pos[0];
            int py = pos[1];

            List<Module> mods = BeretonClient.moduleManager.getByCategory(cat);
            int panelHeight = HEADER_HEIGHT + mods.size() * MODULE_HEIGHT;

            // Settings panel extra height
            int settingsExtra = 0;
            if (openSettings != null && openSettings.category == cat) {
                settingsExtra = openSettings.settings.size() * 14 + 6;
            }

            // Panel background
            ctx.fill(px, py, px + PANEL_WIDTH, py + panelHeight + settingsExtra, COL_PANEL_BG);

            // Header
            ctx.fill(px, py, px + PANEL_WIDTH, py + HEADER_HEIGHT, COL_HEADER);
            ctx.drawTextWithShadow(this.textRenderer, cat.displayName,
                    px + 4, py + 3, COL_ACCENT);

            // Module rows
            int my = py + HEADER_HEIGHT;
            for (Module m : mods) {
                int rowColor = m.isEnabled() ? COL_MOD_ON : COL_MOD_BG;
                ctx.fill(px + 2, my, px + PANEL_WIDTH - 2, my + MODULE_HEIGHT, rowColor);
                ctx.drawTextWithShadow(this.textRenderer, m.name,
                        px + 5, my + 2, m.isEnabled() ? COL_TEXT : COL_TEXT_DIM);

                // Inline settings panel
                if (openSettings == m) {
                    int sy = my + MODULE_HEIGHT;
                    ctx.fill(px + 2, sy, px + PANEL_WIDTH - 2,
                             sy + m.settings.size() * 14 + 4, COL_SETTINGS);
                    int sRow = sy + 2;
                    for (Setting<?> setting : m.settings) {
                        renderSetting(ctx, setting, px + 5, sRow, PANEL_WIDTH - 12, mouseX, mouseY);
                        sRow += 14;
                    }
                }

                my += MODULE_HEIGHT;
                if (openSettings == m) my += openSettings.settings.size() * 14 + 6;
            }
        }

        super.render(ctx, mouseX, mouseY, delta);
    }

    private void renderSetting(DrawContext ctx, Setting<?> s, int x, int y, int w, int mx, int my) {
        if (s instanceof BooleanSetting bs) {
            ctx.drawTextWithShadow(this.textRenderer, s.name + ": " + (bs.isEnabled() ? "§aON" : "§cOFF"),
                    x, y + 2, COL_TEXT);

        } else if (s instanceof EnumSetting<?> es) {
            ctx.drawTextWithShadow(this.textRenderer, s.name + ": §e" + es.getValue().toString(),
                    x, y + 2, COL_TEXT);

        } else if (s instanceof NumberSetting ns) {
            String label = s.name + ": §b" + String.format("%.1f", ns.getValue());
            ctx.drawTextWithShadow(this.textRenderer, label, x, y + 2, COL_TEXT);

            // Slider bar
            int barX = x;
            int barY = y + 10;
            int barW = w;
            double ratio = (ns.getValue() - ns.min) / (ns.max - ns.min);
            ctx.fill(barX, barY, barX + barW, barY + 2, 0xFF333355);
            ctx.fill(barX, barY, barX + (int)(barW * ratio), barY + 2, COL_ACCENT);
        }
    }

    // ─── Mouse events ─────────────────────────────────────────────────

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int mx = (int) mouseX;
        int my = (int) mouseY;

        for (Category cat : Category.values()) {
            int[] pos = panelPos.get(cat);
            int px = pos[0];
            int py = pos[1];
            List<Module> mods = BeretonClient.moduleManager.getByCategory(cat);

            // Header drag start
            if (mx >= px && mx <= px + PANEL_WIDTH && my >= py && my <= py + HEADER_HEIGHT) {
                if (button == 0) {
                    dragCat  = cat.ordinal();
                    dragOffX = mx - px;
                    dragOffY = my - py;
                }
                return true;
            }

            int rowY = py + HEADER_HEIGHT;
            for (Module m : mods) {
                int rowBottom = rowY + MODULE_HEIGHT;
                // Extend bottom if settings open for this module
                if (openSettings == m) rowBottom += m.settings.size() * 14 + 6;

                if (mx >= px + 2 && mx <= px + PANEL_WIDTH - 2 && my >= rowY && my < rowY + MODULE_HEIGHT) {
                    if (button == 0) {
                        m.toggle();
                    } else if (button == 1) {
                        openSettings = (openSettings == m) ? null : m;
                    }
                    return true;
                }

                // Settings interactions
                if (openSettings == m && my >= rowY + MODULE_HEIGHT && my < rowBottom) {
                    int sIdx = (my - (rowY + MODULE_HEIGHT)) / 14;
                    if (sIdx >= 0 && sIdx < m.settings.size()) {
                        handleSettingClick(m.settings.get(sIdx), mx - (px + 5),
                                PANEL_WIDTH - 12, button);
                    }
                    return true;
                }

                rowY = rowBottom;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (dragCat != -1 && button == 0) {
            Category cat = Category.values()[dragCat];
            int[] pos = panelPos.get(cat);
            pos[0] = (int) mouseX - dragOffX;
            pos[1] = (int) mouseY - dragOffY;
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragCat = -1;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        // Scroll to adjust NumberSetting values
        if (openSettings == null) return false;
        int mx = (int) mouseX;
        int my = (int) mouseY;

        for (Category cat : Category.values()) {
            int[] pos = panelPos.get(cat);
            int px = pos[0];
            int py = pos[1];
            List<Module> mods = BeretonClient.moduleManager.getByCategory(cat);
            int rowY = py + HEADER_HEIGHT;

            for (Module m : mods) {
                int rowBottom = rowY + MODULE_HEIGHT + (openSettings == m ? m.settings.size() * 14 + 6 : 0);
                if (openSettings == m && my >= rowY + MODULE_HEIGHT && my < rowBottom) {
                    int sIdx = (my - (rowY + MODULE_HEIGHT)) / 14;
                    if (sIdx >= 0 && sIdx < m.settings.size()) {
                        Setting<?> s = m.settings.get(sIdx);
                        if (s instanceof NumberSetting ns) {
                            ns.setValue(ns.getValue() + verticalAmount * ns.step);
                        }
                    }
                    return true;
                }
                rowY = rowBottom;
            }
        }
        return false;
    }

    @SuppressWarnings({"unchecked","rawtypes"})
    private void handleSettingClick(Setting<?> s, int localX, int width, int button) {
        if (s instanceof BooleanSetting bs) {
            bs.toggle();
        } else if (s instanceof EnumSetting es) {
            es.cycle();
        } else if (s instanceof NumberSetting ns && localX >= 0) {
            // Click on slider bar to set value
            int barW = width;
            double ratio = (double) localX / barW;
            ns.setValue(ns.min + ratio * (ns.max - ns.min));
        }
    }
}
