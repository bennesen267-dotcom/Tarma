package com.bereton.mixin;

import com.bereton.BeretonClient;
import com.bereton.gui.ClickGUI;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;

/**
 * Placeholder for future render-level hooks (e.g., ESP, chams).
 * GUI is opened via KeyBinding in BeretonClient — no injection needed here.
 */
@Mixin(GameRenderer.class)
public class MixinGameRenderer {
    // reserved for render hooks
}
