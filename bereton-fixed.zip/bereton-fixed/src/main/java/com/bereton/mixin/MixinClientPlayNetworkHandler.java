package com.bereton.mixin;

import com.bereton.BeretonClient;
import com.bereton.modules.combat.Aura;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

/**
 * Intercepts outgoing PlayerMoveC2SPacket to optionally override yaw/pitch.
 *
 * When Aura is running and Client Look is DISABLED, we want the server to
 * see our rotated angles but the camera to stay wherever the player left it.
 * Aura already sends explicit LookAndOnGround packets for the server;
 * this mixin cancels the vanilla position-and-look combined packet's look
 * component so we don't override Aura's carefully timed rotations.
 */
@Mixin(ClientPlayNetworkHandler.class)
public class MixinClientPlayNetworkHandler {
    // No active injection needed: Aura sends its own rotation packets directly.
    // This class exists as a hook point for future packet-level modifications.
}
