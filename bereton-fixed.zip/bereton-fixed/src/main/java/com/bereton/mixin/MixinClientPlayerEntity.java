package com.bereton.mixin;

import com.bereton.BeretonClient;
import com.bereton.modules.combat.Aura;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public class MixinClientPlayerEntity {

    /**
     * When Aura's Track option is active, we redirect the player's
     * movement yaw so the character walks toward the locked target
     * regardless of where the camera is pointing.
     *
     * We inject at the start of tickMovement so we can override the
     * movement-input angle before velocity is calculated.
     */
    @Inject(method = "tickMovement", at = @At("HEAD"))
    private void onTickMovement(CallbackInfo ci) {
        if (BeretonClient.moduleManager == null) return;
        Aura aura = BeretonClient.moduleManager.aura;
        if (!aura.isEnabled() || !aura.track.isEnabled()) {
            Aura.clearDesiredMoveYaw();
            return;
        }

        float desiredYaw = Aura.getDesiredMoveYaw();
        if (Float.isNaN(desiredYaw)) return;

        ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;

        // Temporarily set yaw to the desired movement direction.
        // Vanilla uses player.getYaw() when converting forwardInput → velocity.
        // We swap it here, let the movement tick run, then it will be
        // overwritten by the camera yaw (or kept if clientLook is on).
        self.setYaw(desiredYaw);
        Aura.clearDesiredMoveYaw();
    }
}
