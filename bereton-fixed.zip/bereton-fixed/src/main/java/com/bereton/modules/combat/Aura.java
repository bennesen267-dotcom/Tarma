package com.bereton.modules.combat;

import com.bereton.BeretonClient;
import com.bereton.module.Category;
import com.bereton.module.Module;
import com.bereton.module.settings.BooleanSetting;
import com.bereton.module.settings.EnumSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

public class Aura extends Module {

    public enum RotationMode { LEGIT, POLARAC }

    public final EnumSetting<RotationMode> rotations =
            register(new EnumSetting<>("Rotations", RotationMode.LEGIT));
    public final BooleanSetting onlyWeapon =
            register(new BooleanSetting("Only Weapon", true));
    public final BooleanSetting clientLook =
            register(new BooleanSetting("Client Look", false));
    public final BooleanSetting onlyCrits =
            register(new BooleanSetting("Only Crits", true));
    public final BooleanSetting shieldBreaker =
            register(new BooleanSetting("Shield Breaker", true));
    public final BooleanSetting wallDetect =
            register(new BooleanSetting("Wall Detect", true));
    public final BooleanSetting focus =
            register(new BooleanSetting("Focus", false));
    public final BooleanSetting track =
            register(new BooleanSetting("Track", false));

    private LivingEntity target   = null;
    private float serverYaw       = 0f;
    private float serverPitch     = 0f;
    private boolean wasAxe        = false;
    private int prevSlot          = -1;

    private static final Random RNG = new Random();
    private static float desiredMoveYaw = Float.NaN;

    public Aura() { super("Aura", Category.COMBAT); }

    @Override
    protected void onDisable() {
        target = null;
        restorePrevSlot();
    }

    @Override
    public void onTick() {
        MinecraftClient mc = BeretonClient.mc();
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        PlayerEntity player = mc.player;

        if (onlyWeapon.isEnabled() && !isWeapon(player.getMainHandStack().getItem())) return;

        LivingEntity nextTarget = selectTarget(mc, player);

        if (nextTarget == null) {
            if (!focus.isEnabled()) target = null;
            restorePrevSlot();
            return;
        }

        if (focus.isEnabled() && target != null && target.isAlive() && !target.isRemoved()) {
            // keep locked target
        } else {
            target = nextTarget;
        }

        if (track.isEnabled()) {
            Vec3d dir = target.getPos().subtract(player.getPos()).normalize();
            desiredMoveYaw = (float) Math.toDegrees(Math.atan2(-dir.x, dir.z));
        }

        float[] rot = calculateRotation(player, target);
        float targetYaw = rot[0], targetPitch = rot[1];
        float finalYaw, finalPitch;

        if (rotations.getValue() == RotationMode.POLARAC) {
            float dy = MathHelper.clamp(MathHelper.wrapDegrees(targetYaw - serverYaw), -32f, 32f);
            float dp = MathHelper.clamp(MathHelper.wrapDegrees(targetPitch - serverPitch), -28f, 28f);
            finalYaw   = quantise(serverYaw + dy);
            finalPitch = quantise(serverPitch + dp);
        } else {
            float t = 0.35f + RNG.nextFloat() * 0.10f;
            finalYaw   = lerpAngle(serverYaw, targetYaw, t) + (RNG.nextFloat() - 0.5f) * 0.4f;
            finalPitch = lerpAngle(serverPitch, targetPitch, t) + (RNG.nextFloat() - 0.5f) * 0.25f;
        }

        serverYaw = finalYaw; serverPitch = finalPitch;

        mc.getNetworkHandler().sendPacket(
                new PlayerMoveC2SPacket.LookAndOnGround(finalYaw, finalPitch, player.isOnGround(), false)
        );

        if (clientLook.isEnabled()) {
            player.setYaw(finalYaw);
            player.setPitch(finalPitch);
        }

        if (shieldBreaker.isEnabled() && target.isBlocking()) {
            swapToAxe(mc, player);
        } else if (!target.isBlocking()) {
            restorePrevSlot();
        }

        if (onlyCrits.isEnabled()) {
            if (player.isOnGround() && !player.isTouchingWater() && !player.isInLava()) {
                player.jump();
                return;
            }
            if (player.getVelocity().y >= -0.0001) return;
        }

        if (player.getAttackCooldownProgress(0.5f) < 1.0f) return;

        mc.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
    }

    private LivingEntity selectTarget(MinecraftClient mc, PlayerEntity player) {
        List<LivingEntity> candidates = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le)) continue;
            if (le == player || !le.isAlive() || le.isRemoved()) continue;
            if (!(le instanceof PlayerEntity)) continue;
            if (le.distanceTo(player) > 4.5) continue;
            if (wallDetect.isEnabled() && hasWall(mc, player, le)) continue;
            candidates.add(le);
        }
        if (candidates.isEmpty()) return null;
        if (focus.isEnabled() && target != null && candidates.contains(target)) return target;
        candidates.sort(Comparator.comparingDouble(e -> e.distanceTo(player)));
        return candidates.get(0);
    }

    private boolean hasWall(MinecraftClient mc, PlayerEntity player, LivingEntity entity) {
        Vec3d eye = player.getCameraPosVec(1f);
        Vec3d tgt = entity.getCameraPosVec(1f);
        HitResult hit = mc.world.raycast(new RaycastContext(
                eye, tgt, RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE, player));
        return hit.getType() != HitResult.Type.MISS;
    }

    private float[] calculateRotation(PlayerEntity player, LivingEntity target) {
        Vec3d eye = player.getCameraPosVec(1f);
        Vec3d tgt = target.getBoundingBox().getCenter();
        double dx = tgt.x - eye.x, dy = tgt.y - eye.y, dz = tgt.z - eye.z;
        double dist = Math.sqrt(dx * dx + dz * dz);
        return new float[]{
                (float) Math.toDegrees(Math.atan2(-dx, dz)),
                MathHelper.clamp((float) -Math.toDegrees(Math.atan2(dy, dist)), -90f, 90f)
        };
    }

    private float lerpAngle(float cur, float tgt, float t) {
        return cur + MathHelper.wrapDegrees(tgt - cur) * t;
    }

    private float quantise(float a) { return Math.round(a / 0.05f) * 0.05f; }

    private void swapToAxe(MinecraftClient mc, PlayerEntity player) {
        if (wasAxe) return;
        for (int i = 0; i < 9; i++) {
            if (player.getInventory().getStack(i).getItem() instanceof AxeItem) {
                prevSlot = player.getInventory().selectedSlot;
                player.getInventory().selectedSlot = i;
                wasAxe = true;
                return;
            }
        }
    }

    private void restorePrevSlot() {
        if (!wasAxe || prevSlot == -1) return;
        MinecraftClient mc = BeretonClient.mc();
        if (mc.player == null) return;
        mc.player.getInventory().selectedSlot = prevSlot;
        prevSlot = -1; wasAxe = false;
    }

    private boolean isWeapon(Item item) {
        return item instanceof SwordItem || item instanceof AxeItem || item instanceof TridentItem;
    }

    public static float getDesiredMoveYaw() { return desiredMoveYaw; }
    public static void clearDesiredMoveYaw() { desiredMoveYaw = Float.NaN; }
}
