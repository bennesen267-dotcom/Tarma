package com.bereton.modules.combat;

import com.bereton.BeretonClient;
import com.bereton.module.Category;
import com.bereton.module.Module;
import com.bereton.module.settings.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;

public class AutoTotem extends Module {

    public final NumberSetting health =
            register(new NumberSetting("Health", 8.0, 1.0, 20.0, 0.5));

    public final NumberSetting elytraHealth =
            register(new NumberSetting("Elytra Health", 14.0, 1.0, 20.0, 0.5));

    public final NumberSetting delay =
            register(new NumberSetting("Delay", 1.0, 0.0, 10.0, 1.0));

    private static final int OFFHAND_SLOT = 45;
    private int cooldown = 0;

    public AutoTotem() {
        super("Auto Totem", Category.COMBAT);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = BeretonClient.mc();
        if (mc.player == null || mc.world == null) return;

        ClientPlayerEntity player = mc.player;

        if (cooldown > 0) { cooldown--; return; }

        if (player.getOffHandStack().getItem() == Items.TOTEM_OF_UNDYING) return;

        boolean wearingElytra = player.getInventory().getArmorStack(2).getItem() == Items.ELYTRA;
        double threshold = wearingElytra ? elytraHealth.getValue() : health.getValue();

        if (player.getHealth() > threshold) return;

        int totemSlot = findTotemSlot(player.getInventory());
        if (totemSlot == -1) return;

        swapToOffhand(mc, player, totemSlot);
        cooldown = delay.getInt();
    }

    private void swapToOffhand(MinecraftClient mc, ClientPlayerEntity player, int invSlot) {
        // Use the built-in screen handler method to swap — avoids packet constructor issues
        int screenSlot = invSlot < 9 ? 36 + invSlot : invSlot;

        // Simulate click via interactionManager — works without opening inventory
        mc.interactionManager.clickSlot(
                player.playerScreenHandler.syncId,
                screenSlot,
                0,
                SlotActionType.PICKUP,
                player
        );
        mc.interactionManager.clickSlot(
                player.playerScreenHandler.syncId,
                OFFHAND_SLOT,
                0,
                SlotActionType.PICKUP,
                player
        );
        mc.interactionManager.clickSlot(
                player.playerScreenHandler.syncId,
                screenSlot,
                0,
                SlotActionType.PICKUP,
                player
        );
    }

    private int findTotemSlot(PlayerInventory inv) {
        for (int i = 0; i < 9;  i++) if (inv.getStack(i).getItem() == Items.TOTEM_OF_UNDYING) return i;
        for (int i = 9; i < 36; i++) if (inv.getStack(i).getItem() == Items.TOTEM_OF_UNDYING) return i;
        return -1;
    }
}
