package com.bereton.module.settings;

public class EnumSetting<E extends Enum<E>> extends Setting<E> {

    private final E[] values;

    public EnumSetting(String name, E defaultValue) {
        super(name, defaultValue);
        //noinspection unchecked
        this.values = (E[]) defaultValue.getDeclaringClass().getEnumConstants();
    }

    /** Cycles to the next enum constant. */
    public void cycle() {
        int next = (value.ordinal() + 1) % values.length;
        value = values[next];
    }

    public E[] getValues() { return values; }
}
