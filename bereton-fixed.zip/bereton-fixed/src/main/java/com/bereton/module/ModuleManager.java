package com.bereton.module;

import com.bereton.modules.combat.Aura;
import com.bereton.modules.combat.AutoPotions;
import com.bereton.modules.combat.AutoTotem;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {

    public final List<Module> modules = new ArrayList<>();

    public Aura aura;
    public AutoTotem autoTotem;
    public AutoPotions autoPotions;

    public void init() {
        aura       = register(new Aura());
        autoTotem  = register(new AutoTotem());
        autoPotions = register(new AutoPotions());

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;
            for (Module m : modules) {
                if (m.isEnabled()) m.onTick();
            }
        });
    }

    private <T extends Module> T register(T module) {
        modules.add(module);
        return module;
    }

    public List<Module> getByCategory(Category cat) {
        return modules.stream().filter(m -> m.category == cat).toList();
    }
}
